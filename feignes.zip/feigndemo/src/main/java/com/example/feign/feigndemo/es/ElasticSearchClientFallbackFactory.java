package com.example.feign.feigndemo.es;

import feign.hystrix.FallbackFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ElasticSearchClientFallbackFactory implements FallbackFactory<ElasticSearchClient> {

    @Override
    public ElasticSearchClient create(Throwable cause) {
        return new ElasticSearchClient() {
            @Override
            public Map search(String indexName, Map queryarams) {
                return getMap(cause);
            }

            @Override
            public Map msearch(List<Map> queryParams) {
                return getMap(cause);
            }

            @Override
            public Map update(String index, String type, String id, Map queryParams) {
                return getMap(cause);
            }

            @Override
            public Map bulk(String queryParams) {
                return getMap(cause);
            }

            @Override
            public Map getIndexName(String indexAlias) {
                return getMap(cause);
            }

            @Override
            public Map postAliases(String queryParams) {
                return getMap(cause);
            }

            @Override
            public Map reIndex(String queryParams) {
                return getMap(cause);
            }

            @Override
            public Map putMapping(String index, String type, String queryParams) {
                return getMap(cause);
            }
        };


    }

    public Map getMap(Throwable cause) {
        return new HashMap() {{
            put("code","1");
            put("msg","fallback;reason was:"+cause.getMessage());
            put("data",null);
        }

        };
    }
}
