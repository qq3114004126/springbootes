package com.example.feign.feigndemo.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GlobalDefaultExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(GlobalDefaultExceptionHandler.class);

}
