package com.feign.feigndemo.service;

import com.feign.feigndemo.entity.Customer;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class ExampleHystrixFeignFallBackFactory implements FallbackFactory<ExampleFeignClientService> {

    private static final Logger LOG = LoggerFactory.getLogger(ExampleHystrixFeignFallBackFactory.class);

    @Override
    public ExampleFeignClientService create(Throwable cause) {
        LOG.error("fallback; reason was: " + cause.getMessage(), cause);

        return new ExampleFeignClientService() {
            @Override
            public Customer demo10(String id) {
                return ;

            }
        };
    }
}
