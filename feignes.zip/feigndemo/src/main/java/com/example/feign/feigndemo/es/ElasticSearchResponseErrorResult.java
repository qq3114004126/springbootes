package com.example.feign.feigndemo.es;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class ElasticSearchResponseErrorResult {

    private Error error;
    private Integer status;

    @Data
    static class Error{
        @JSONField(name = "root_cause")
        private List<RootCause> rootCause;
        private String type;
        private String reason;

    }


    static class RootCause{
        private String type;
        private String reason;
    }
}