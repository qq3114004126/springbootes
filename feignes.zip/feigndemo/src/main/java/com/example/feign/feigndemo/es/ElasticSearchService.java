package com.example.feign.feigndemo.es;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.feign.feigndemo.pojo.ResponseResult;
import jdk.management.resource.internal.inst.FileOutputStreamRMHooks;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ElasticSearchService {
    private static final Logger LOG = LoggerFactory.getLogger(ElasticSearchService.class);

    @Autowired
    private ElasticSearchClient elasticSearchClient;

    /**
     *
     * 单个查询
     * @param indexName
     * @param queryParams
     * @return
     */
    public ResponseResult search(String indexName,Map queryParams) {
        Map result = elasticSearchClient.search(indexName, queryParams);
        return ResponseResult.success("SUCCESS!",getEsReponseData(result));
    }

    /**
     * 批量查询
     * @param queryParam
     * @return
     */
    public ResponseResult mSearch(List<Map> queryParam) {
        Map msearch = elasticSearchClient.msearch(queryParam);
        JSONObject jsonObject = new JSONObject(msearch);
        JSONArray responses = jsonObject.getJSONArray("responses");
        List<EsReponseData> objectLinkedList = new LinkedList<>();
        for (Object object:responses) {
            Map<String,Object> obj = null;
            if (object instanceof Map) {
               obj = (Map<String,Object>)object;
            }
            objectLinkedList.add(getEsReponseData(obj));
        }
        return ResponseResult.success("search successfully!",objectLinkedList);
    }

    /**
     * 单个更新
     * @param index
     * @param type
     * @param id
     * @param queryParams
     * @return
     */
    public ResponseResult update(String index,String type,String id,Map queryParams) {
        Map updateResult = elasticSearchClient.update(index, type, id, queryParams);
        return ResponseResult.success("search successfully!",updateResult);
    }

    /**
     * 批量更新
     *
     * @return
     */
    public ResponseResult bulk(List<Map> list) {
        Map bulk = elasticSearchClient.bulk(listToString(list));
        return ResponseResult.success("search successfully!",bulk);
    }

    public EsReponseData getEsReponseData(Map queryParam) {
        JSONObject jsonObject = new JSONObject(queryParam);
        String total = jsonObject.getJSONObject("hits").getString("total");
        JSONArray jsonArray = jsonObject.getJSONObject("hits").getJSONArray("hits");
        ArrayList<Map> list = new ArrayList<>();
        String index = null;
        String type = null;
        String id = null;
        for (Object object :jsonArray) {
            Map map = null;
            if (object instanceof Map) {
                map = (Map) object;
            }
            Object source = null;
            if (map !=null) {
                if (map.get("_index") instanceof String) {
                    index = (String)map.get("_index");
                }
                if (map.get("_type") instanceof String) {
                     type = (String) map.get("_type");
                }
                if (map.get("_id") instanceof String) {
                    id = (String)map.get("_id");
                }
                source = map.get("_source");
            }

            Map<String, Object> map2 = new HashMap<>();
            map2.put("id",id);
            if (source instanceof Map) {
               Map sourceMap =  (Map)source;
                Set<String> set = sourceMap.keySet();
                for (String key:set) {
                    Object value = sourceMap.get(key);
                    map2.put(key,value);
                }
                list.add(map2);
            }

        }
        return new EsReponseData(index,total,list);
    }

    /**
     *
     */

    public String listToString(List<Map> mapList) {
        StringBuffer queryParamStr = new StringBuffer();
        if (CollectionUtils.isEmpty(mapList)) {
            LOG.debug("search param is empty.");
        } else {
            mapList.stream().forEach(map -> {
                LOG.debug("search param item {}.",map);
                String newLine = System.lineSeparator();
                queryParamStr.append(JSONObject.toJSONString(map)).append(newLine);
            });
        }
        LOG.debug("search params: {}",queryParamStr);
        LOG.info("search params: {}",queryParamStr);

        return queryParamStr.toString();
    }

}