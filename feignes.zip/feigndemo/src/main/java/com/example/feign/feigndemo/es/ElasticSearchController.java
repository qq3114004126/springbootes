package com.example.feign.feigndemo.es;

import com.example.feign.feigndemo.pojo.ResponseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Action;
import java.util.Map;


@RestController
@RequestMapping("/v1/elasticsearch")
public class ElasticSearchController {

    private static final Logger LOG = LoggerFactory.getLogger(ElasticSearchController.class);

    @Autowired
    private ElasticSearchService elasticSearchService;

    @PostMapping("/{indexName}/search")
    public ResponseResult search(@PathVariable(name = "indexName",required = false) String indexName, @RequestBody Map queryParams) {
        ResponseResult search = elasticSearchService.search(indexName, queryParams);
        return search;
    }
}
