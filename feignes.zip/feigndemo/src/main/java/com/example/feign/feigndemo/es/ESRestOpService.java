package com.example.feign.feigndemo.es;

import org.elasticsearch.action.ActionFuture;
import org.elasticsearch.action.admin.indices.alias.Alias;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

@Service
public class ESRestOpService {
    private static final Logger LOG = LoggerFactory.getLogger(ESRestOpService.class);

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;
    @Autowired
    private ElasticSearchClient elasticSearchClient;

    public boolean exists(String indexName) {
        return  elasticsearchTemplate.indexExists(indexName);
    }

    public boolean createIndex(String indexName,String typeName,String mapping,String...indexAlias){
        CreateIndexRequest request = new CreateIndexRequest();
        request.settings(Settings.builder().put("index_number_of_shards",3).put("index_number_of_replicas",2));
        for (String alias:indexAlias) {
          request.alias(new Alias(alias));
        }
        request.mapping(typeName,mapping,XContentType.JSON);
        CreateIndexResponse response = (CreateIndexResponse) elasticsearchTemplate.getClient().admin().indices().create(request);
        return response.isAcknowledged();
    }

    public void putMapping(String indexName,String typeName,String mapping){
        Map map = elasticSearchClient.putMapping(indexName, typeName, mapping);
    }

    public Boolean deleteIndex(String indexName) {
        return elasticsearchTemplate.deleteIndex(indexName);
    }

    public void reIndex(String sourceIndex,String destIndex) {
        String pattern = "{\"source\":{\"index\":\"%1s\"},\"dest\":{\"index\":\"%2s\"}}";
        String format = String.format(Locale.ROOT, pattern, sourceIndex, destIndex);
        Map map = elasticSearchClient.reIndex(format);
    }

    public Map getIndexName(String indexAlias) {
        Map indexName = elasticSearchClient.getIndexName(indexAlias);
        return indexName;
    }


    public void postAliases(String sourceIndex,String destIndex,String alias) {

        String entityString = "{\"actions\":[{\"remove\":{\"index\":\""+ sourceIndex + "\",\"alias\":\"" + alias +"\"}},{\"add\":{\"index\""+destIndex+"\",\"alias\":\""+alias+"\"}}}]}";
        Map map = elasticSearchClient.postAliases(entityString);
    }
}
