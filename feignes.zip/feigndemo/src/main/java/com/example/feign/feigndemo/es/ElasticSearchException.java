package com.example.feign.feigndemo.es;

public class ElasticSearchException extends RuntimeException {

    private int status = 503;
    public ElasticSearchException(String message,int status) {
        super(message);
        this.status = status;
    }
}