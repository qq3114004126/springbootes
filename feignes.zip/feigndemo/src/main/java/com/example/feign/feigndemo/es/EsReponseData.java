package com.example.feign.feigndemo.es;

import java.util.List;
import java.util.Map;

public class EsReponseData {

    private String index;
    private String total;
    private List<Map> data;

    public EsReponseData() {
    }

    public EsReponseData(String index, String total, List<Map> data) {
        this.index = index;
        this.total = total;
        this.data = data;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public List<Map> getData() {
        return data;
    }

    public void setData(List<Map> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "EsReponseData{" +
                "index='" + index + '\'' +
                ", total='" + total + '\'' +
                ", data=" + data +
                '}';
    }
}
