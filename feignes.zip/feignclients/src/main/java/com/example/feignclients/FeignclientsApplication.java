package com.example.feignclients;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignclientsApplication {

    public static void main(String[] args) {
        SpringApplication.run(FeignclientsApplication.class, args);
    }

}
