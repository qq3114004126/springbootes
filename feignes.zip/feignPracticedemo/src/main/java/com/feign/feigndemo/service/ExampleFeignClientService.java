package com.feign.feigndemo.service;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "shanhy-example1", path = "/shanhy-example1", fallbackFactory = ExampleHystrixFeignFallBackFactory.class)
public interface ExampleFeignClientService extends FeignInterfaceAop {
}
