package com.example.feignclients.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeignController {
    private static IWeaveClient  iWeaveRequestor;

    public FeignController(IWea weaveRequestor) {
        this
    }
}
