package com.feign.feigndemo.service;

import com.feign.feigndemo.entity.Customer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/example")
public interface FeignInterfaceAop {

    @GetMapping("/test10/{id}")
    public Customer demo10(@PathVariable String id);
}
