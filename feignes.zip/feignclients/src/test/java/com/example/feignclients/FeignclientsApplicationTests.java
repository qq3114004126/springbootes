package com.example.feignclients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignclientsApplicationTests {

    @Test
    void contextLoads() {
    }

}
