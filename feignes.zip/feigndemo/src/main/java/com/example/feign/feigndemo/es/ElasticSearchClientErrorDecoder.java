package com.example.feign.feigndemo.es;



import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPObject;
import feign.Response;
import feign.Util;
import feign.codec.ErrorDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.io.IOException;

public class ElasticSearchClientErrorDecoder implements ErrorDecoder {

    private static final Logger LOG = LoggerFactory.getLogger(ElasticSearchClientErrorDecoder.class);

    public static final String DEFAULT_ERROR = "query failed!";
    @Override
    public Exception decode(String s, Response response) {
        Exception exception = null;
        try {
            String json = Util.toString(response.body().asReader());
            if (StringUtils.isEmpty(json)){
                return new RuntimeException(DEFAULT_ERROR);
            }
            ElasticSearchResponseErrorResult result = JSONObject.parseObject(json, ElasticSearchResponseErrorResult.class);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
