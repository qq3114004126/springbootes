package com.example.feign.feigndemo.es;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;
@FeignClient(name = "${feign.name}",url = "${feign.url}",configuration = FeignConfiguration.class,fallbackFactory = ElasticSearchClientFallbackFactory.class)
public interface ElasticSearchClient {

    /**
     * 单个搜索
     * @param indexName
     * @param queryarams
     * @return
     */
    @RequestMapping(method = RequestMethod.POST,value = "/{indexName}/_search",consumes = "application/json")
    Map search(@PathVariable(name = "indexName",required = false) String indexName,Map queryarams);

    /**
     * 批量搜索
     * @param queryParams
     * @return
     */
    @RequestMapping(method = RequestMethod.POST,value = "/_msearch",consumes = "application/json")
    Map msearch(List<Map> queryParams);

    /**
     * 单个更新
     * @param index
     * @param type
     * @param id
     * @param queryParams
     * @return
     */
    @RequestMapping(method = RequestMethod.POST,value = "/{index}/{type}/{id}/_update",consumes = "application/json")
    Map update(@PathVariable("index") String index,@PathVariable("type") String type,@PathVariable("id")String id,Map queryParams);

    /**
     * 批量更新
     * @param queryParams
     * @return
     */
    @RequestMapping(method = RequestMethod.POST,value = "/_value",consumes = "application/json")
    Map bulk(String queryParams);

    /**
     * 获取索引
     * @param indexAlias
     * @return
     */
    @RequestMapping(method = RequestMethod.GET,value = "/_alias/{indexAlias}")
    Map getIndexName(@PathVariable("indexAlias") String indexAlias);

    @RequestMapping(method = RequestMethod.POST,value = "/_aliases",consumes = "application/json")
    Map postAliases(String queryParams);

    /**
     *
     * 索引重建
     */
    @RequestMapping(method = RequestMethod.POST,value = "/_reIndex",consumes = "application/json")
    Map reIndex(String queryParams);

    /**
     *
     * @param index
     * @param type
     * @param queryParams
     * @return
     */
    @RequestMapping(method = RequestMethod.PUT,value = "/{index}/_mapping/{type}",consumes = "application/json")
    Map putMapping(@PathVariable("index") String index,@PathVariable("type")String type,String queryParams);


}