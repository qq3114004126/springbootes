package com.example.feign.feigndemo.exception;

public class BusinessException extends RuntimeException {

    private static final long serialVersonID = 1L;

    private String msg;

    public BusinessException(final String newMsg) {
        this.msg = newMsg;
    }

    public final String getMsg() {
        return msg;
    }

    public final void setMsg(final String oldMsg) {
        this.msg = oldMsg;
    }
}
