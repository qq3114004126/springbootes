package com.example.feignclientdemos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignclientdemosApplication {

    public static void main(String[] args) {
        SpringApplication.run(FeignclientdemosApplication.class, args);
    }

}
